// BEGIN
const customBind = (obj, fn) => {
    return function() {
        return fn.apply(obj, arguments);
    };
};

export default customBind;
// END