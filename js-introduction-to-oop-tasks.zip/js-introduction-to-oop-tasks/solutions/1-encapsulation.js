// BEGIN
export function getMutualFriends(user1, user2) {
  const a = user1.getFriends();
  const b = user2.getFriends();
  let ans = [];
  for (let friend of a) {
    for (let fr of b) {
      if (friend.id === fr.id) {
        ans.push(friend);
      }
    }
  }

  return ans;
};

// END

export default ({ id = null, friends = [] } = {}) => ({
  friends,
  id,
  getFriends() {
    return this.friends.slice(); // возвращение копии массива, чтобы его не изменили извне
  },
});